package kr.or.bit.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.bit.action.Action;
import kr.or.bit.action.ActionForward;
import kr.or.bit.dao.EmpDao;

public class EmpDetailService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("userid") == null || !session.getAttribute("userid").equals("admin") ){
			//강제로 페이지 이동
			out.print("<script>location.href='Ex02_JDBC_Login.jsp'</script>");
		}
		
		
		String id = request.getParameter("id");
		
		EmpDao ed = new EmpDao();
		ResultSet rs = ed.empDetail(id);
		while(rs.next()){
			String rsid = rs.getString("id");
			String pwd = rs.getString("pwd");
			String name = rs.getString("name");
			String age = rs.getString("age");
			String gender = rs.getString("gender");
			String email = rs.getString("email");
			out.print("<table style='width: 400px;height: 100px;margin-left: auto;margin-right: auto;'>");
			out.print("<tr>");
			out.print("<td style='width:100px'>아이디</td>");
			out.print("<td style='width:100px'>" + rsid + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td style='width:100px'>비번</td>");
			out.print("<td style='width:100px'>" + pwd + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td style='width:100px'>비번</td>");
			out.print("<td style='width:100px'>" + name + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td style='width:100px'>비번</td>");
			out.print("<td style='width:100px'>" + age + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td style='width:100px'>비번</td>");
			out.print("<td style='width:100px'>" + gender + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td style='width:100px'>비번</td>");
			out.print("<td style='width:100px'>" + pwd + "</td>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<td colspan='2'>");
			out.print("<a href='Ex03_Memberlist.jsp'>목록가기</a>");
		  	out.print("</td>");
		  	out.print("</tr>");
		  	out.print("</table>");	
					
		}
		return null;
	}
}
