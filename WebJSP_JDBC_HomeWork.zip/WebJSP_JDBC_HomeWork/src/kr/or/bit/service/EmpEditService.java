package kr.or.bit.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.bit.action.Action;
import kr.or.bit.action.ActionForward;
import kr.or.bit.dao.EmpDao;
import kr.or.bit.dto.Emp;

public class EmpEditService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 업데이트만 시켜주면 된다.
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		if(session.getAttribute("userid") == null || !session.getAttribute("userid").equals("admin")){
		  //다른 페이지 이동
		  out.print("<script>");
		  out.print("location.href='Ex02_JDBC_Login.jsp'");
		  out.print("</script>");
		}
			 
		request.setCharacterEncoding("UTF-8");
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		//out.print(id + " / " + name + " / " + age + " / " + email);
		
		//update 시키기
		EmpDao ed = new EmpDao();
		Emp emp = new Emp();
		emp.setName(name);
		emp.setAge(age);
		emp.setEmail(email);
		emp.setGender(gender);
		emp.setId(id);
		
		int result = ed.empUpdate(emp);
		
		if(result > 0){
			out.print("<script>");
			out.print("location.href='Ex03_Memberlist.jsp'");
			out.print("</script>");
		}
		
  	    ActionForward forward = new ActionForward();
  	    
  	    if (result > 0) {
	  	    forward.setRedirect(true);
	  	    forward.setPath("/Ex03_Memberlist.do");
  	    }
		return forward;
	}
}
