package kr.or.bit.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.bit.action.Action;
import kr.or.bit.action.ActionForward;

public class EmpLoginOutService implements Action{

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, SQLException {

		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userid");
		System.out.println("userId" + userId);
		String viewpage = null;
		System.out.println("로그아웃 중2222!!");
		
		if(session.getAttribute("userid") != null){
			session.invalidate();
			viewpage = "/Ex02_JDBC_Login.jsp";
			System.out.println("로그아웃 중!!");
		}else{
			viewpage = "/Ex02_JDBC_Login.jsp";
			System.out.println("로그인하는 중!");
		}
		
  	    ActionForward forward = new ActionForward();
  	    forward.setRedirect(false);
  	    forward.setPath(viewpage);
		
		return forward;
	}
	
}
