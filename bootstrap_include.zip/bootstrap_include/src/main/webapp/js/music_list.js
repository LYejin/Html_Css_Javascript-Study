const musicList = [
  {
    name: "히사이시 조",
    artist: "인생의 회전목마",
    img: "https://contents.kyobobook.co.kr/sih/fit-in/458x0/pdt/9791133477210.jpg",
    audio:
      "https://movie4team.s3.ap-northeast-2.amazonaws.com/Howls+Moving+Castle+OST++Theme+Song.mp3",
  },
  {
    name: "히사이시 조",
    artist: "벼랑 위의 포뇨(ost)",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLJ_gJ8FBBlVg8E8UcHqrEIJ1mQ1uZXEnZeNejwGKA0NKq95YzRrHYJBg3fwzJ-nHFaps&usqp=CAU",
    audio:
      "https://movie4team.s3.ap-northeast-2.amazonaws.com/y2mate.com+-+%E9%9F%A9%E5%9B%BDponyo.mp3",
  },
  {
    name: "키무라 유미",
    artist: "센과 치히로의 행방불명",
    img: "https://mblogthumb-phinf.pstatic.net/MjAxNzA2MDRfMjQy/MDAxNDk2NTY4NjI4MjI5.o6qKy0vaoTOHumrOCijDxf0eYxEL16SPJCeoitOYbeEg.eb4qdhFPuB1LRG-xWciJa4pfNw4Ojb646byFPf1RkRkg.JPEG.daekk1228/%EC%84%BC%EA%B3%BC_%EC%B9%98%ED%9E%88%EB%A1%9C%EC%9D%98_%ED%96%89%EB%B0%A9%EB%B6%88%EB%AA%85.jpg?type=w800",
    audio:
      "https://movie4team.s3.ap-northeast-2.amazonaws.com/Always+With+Me.mp3",
  },
  {
    name: "히사이시 조",
    artist: "너를 태우고",
    img: "https://upload.wikimedia.org/wikipedia/ko/9/9f/%EC%B2%9C%EA%B3%B5%EC%9D%98_%EC%84%B1_%EB%9D%BC%ED%93%A8%ED%83%80_%ED%8F%AC%EC%8A%A4%ED%84%B0.jpg",
    audio:
      "https://movie4team.s3.ap-northeast-2.amazonaws.com/%E1%84%85%E1%85%A1%E1%84%91%E1%85%B2%E1%84%90%E1%85%A1.mp3",
  },
  {
    name: "히사이시 조",
    artist: "바다가 보이는 마을",
    img: "https://upload.wikimedia.org/wikipedia/ko/9/9b/%EB%A7%88%EB%85%80%EB%B0%B0%EB%8B%AC%EB%B6%80%ED%82%A4%ED%82%A4_%ED%8F%AC%EC%8A%A4%ED%84%B0.jpg",
    audio:
      "https://movie4team.s3.ap-northeast-2.amazonaws.com/y2mate.com+-+Kikis+Delivery+Service++Umi+No+Mieru+Machi+Piano.mp3",
  },
];
